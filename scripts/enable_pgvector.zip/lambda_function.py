import json
import boto3
import psycopg2
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    Lambda function to enable pgvector extension in PostgreSQL RDS
    """
    
    # Get database credentials from Secrets Manager
    secrets_client = boto3.client('secretsmanager', region_name='ap-south-1')
    
    try:
        response = secrets_client.get_secret_value(SecretId='vesper-dev-db-credentials')
        secret = json.loads(response['SecretString'])
        
        # Connect to PostgreSQL
        conn = psycopg2.connect(
            host=secret['host'],
            port=secret['port'],
            database=secret['dbname'],
            user=secret['username'],
            password=secret['password']
        )
        
        cursor = conn.cursor()
        
        # Enable pgvector extension
        logger.info("Enabling pgvector extension...")
        cursor.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        
        # Verify extension is installed
        cursor.execute("SELECT extname FROM pg_extension WHERE extname = 'vector';")
        result = cursor.fetchone()
        
        if result:
            logger.info("pgvector extension successfully enabled!")
            success_message = "pgvector extension is now available"
        else:
            logger.error("Failed to enable pgvector extension")
            success_message = "Failed to enable pgvector extension"
            
        # Create initial schema if needed
        logger.info("Creating initial database schema...")
        
        # Documents table for storing processed documents
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS documents (
                id SERIAL PRIMARY KEY,
                filename VARCHAR(255) NOT NULL,
                content_type VARCHAR(100),
                file_size BIGINT,
                s3_key VARCHAR(500) NOT NULL,
                status VARCHAR(50) DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        
        # Document chunks table for storing text chunks with vector embeddings
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS document_chunks (
                id SERIAL PRIMARY KEY,
                document_id INTEGER REFERENCES documents(id) ON DELETE CASCADE,
                chunk_index INTEGER NOT NULL,
                content TEXT NOT NULL,
                embedding vector(1536),  -- OpenAI embeddings are 1536 dimensions
                metadata JSONB,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        
        # Create index on embeddings for fast similarity search
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS document_chunks_embedding_idx 
            ON document_chunks USING ivfflat (embedding vector_cosine_ops)
            WITH (lists = 100);
        """)
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': success_message,
                'database_initialized': True
            })
        }
        
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }